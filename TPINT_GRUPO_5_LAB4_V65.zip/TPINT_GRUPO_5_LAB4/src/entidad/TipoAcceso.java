package entidad;

public enum TipoAcceso {
	Administrador, 
	Cliente;
}
