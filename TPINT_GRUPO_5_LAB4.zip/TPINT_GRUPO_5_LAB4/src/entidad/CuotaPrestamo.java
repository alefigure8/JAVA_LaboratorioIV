package entidad;

import java.time.LocalDate;

public class CuotaPrestamo {

	
	//private int id;
	//private int idPrestamo;
	
	private int numeroCuota;
    private double montoCuota;
    private LocalDate fechaVencimiento;
    private LocalDate fechaPago;
    private String estado;
    
    //Estado ENUM('Pendiente', 'Pagado') NOT NULL,
	
	
}
