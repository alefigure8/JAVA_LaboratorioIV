package entidad;

public class TipoTasa {

	private int id;
	private int cantCuotas;
	private double tasaInteres;
	
	     
	
}
