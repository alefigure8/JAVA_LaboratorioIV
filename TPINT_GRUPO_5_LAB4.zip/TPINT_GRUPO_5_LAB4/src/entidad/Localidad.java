package entidad;

public class Localidad {

	private int idLocalidad;
	private String nombre;	
    private int idProvincia;
	
	
}
