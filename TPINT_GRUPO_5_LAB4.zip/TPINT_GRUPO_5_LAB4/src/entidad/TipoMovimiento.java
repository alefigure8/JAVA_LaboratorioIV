package entidad;

public class TipoMovimiento {

	private int id;
	private int descripcion;
	
}
