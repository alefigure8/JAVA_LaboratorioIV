package entidad;

public class Estado {
	
	private int idEstado;
	private String descripcion;
}
