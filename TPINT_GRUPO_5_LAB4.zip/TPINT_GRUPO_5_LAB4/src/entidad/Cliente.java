package entidad;

public class Cliente {
	
	private int DNI;
	private int CUIL;
	private String Nombre;
	private String Apellido;
	private String Sexo;
	private String Nacimiento;		
	private Direccion direccion;
	private String Email;
	private int Telefono;
	private boolean estado;
	
}
