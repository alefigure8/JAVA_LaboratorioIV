package entidad;

public enum EstadoCuota {
	Pendiente,
	Pagado
	
}
