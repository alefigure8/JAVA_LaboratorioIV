package entidad;

public enum Operacion {
	Entrada,
	Salida
}
