package excepciones;

public class CorreoException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public CorreoException(String message) {
		super(message);
	}
}
