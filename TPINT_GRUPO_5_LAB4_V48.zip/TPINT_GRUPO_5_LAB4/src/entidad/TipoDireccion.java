package entidad;

public enum TipoDireccion {
	Casa,
	Departamento
}
