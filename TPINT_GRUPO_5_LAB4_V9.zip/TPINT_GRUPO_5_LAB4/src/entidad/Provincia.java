package entidad;

import java.util.ArrayList;

public class Provincia {

    private int idProvincia;
    private String nombre;

	
}
