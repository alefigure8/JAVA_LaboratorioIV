package entidad;

public class Direccion {
    
	private int id;
	private String calle;
	private int numero;	
	private String tipoDireccion;
	private String numeroDepartamento;
	private int codigoPostal;
	private Localidad localidad;
	private Provincia provincia;
	
	
	
}
