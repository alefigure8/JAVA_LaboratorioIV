package entidad;

public class TipoCuenta {

	 private int id;
	 private String descripcion;
	
}
