package dominio;

public class UsuarioDao {

}
