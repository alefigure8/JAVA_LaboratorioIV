package dominio;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SeguroDao {
	
	private static final String readAll="select * from seguros";
	private static final String readPorTipo="select * from seguros where idTipo = ?";
	private static final String ultimoId = "select idSeguro from seguros order by idSeguro desc limit 1";
	
	//READALL
	public List<Seguro> readAll() {
		PreparedStatement pStatement;
		ResultSet rSet; // guardamos rdo de la consulta
		ArrayList<Seguro> seguros=new ArrayList<Seguro>();
		Conexion conexion= Conexion.getConexion();
		
		try {
			pStatement=conexion.getSQLConexion().prepareStatement(readAll);
			rSet=pStatement.executeQuery();
			while(rSet.next()) {
				seguros.add(getSeguro(rSet));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return seguros;
	}
	
	//READ POR TIPO
	public List<Seguro> readPorTipo(int tipoSeguro) {
		PreparedStatement pStatement;
		ResultSet rSet; // guardamos rdo de la consulta
		ArrayList<Seguro> seguros=new ArrayList<Seguro>();
		Conexion conexion= Conexion.getConexion();
		
		try {
			pStatement=conexion.getSQLConexion().prepareStatement(readPorTipo);
			pStatement.setInt(1, tipoSeguro);
			rSet=pStatement.executeQuery();
			while(rSet.next()) {
				seguros.add(getSeguro(rSet));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return seguros;
	}
	
	
	//GET SEGURO CON EL RESULTSET
	private Seguro getSeguro(ResultSet rSet) throws SQLException {
		int idSeguro = rSet.getInt("idSeguro");
		String descripcion = rSet.getString("descripcion");
		int idTipo = rSet.getInt("idTipo");;
		double costoContratacion = rSet.getDouble("costoContratacion");
		double costoAsegurado = rSet.getDouble("costoAsegurado");
		return new Seguro(idSeguro, descripcion, idTipo, costoContratacion, costoAsegurado);
	}
	
	//ULTIMO ID
	public int ultimoID() {
		PreparedStatement pStatement;
		ResultSet rSet;
		Conexion conexion= Conexion.getConexion();
		int ultimo = 0;
		try {
			pStatement=conexion.getSQLConexion().prepareStatement(ultimoId);
			rSet=pStatement.executeQuery();
			if(rSet.next())
			{
				ultimo = rSet.getInt("idSeguro");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return ultimo;
	}
	

}
