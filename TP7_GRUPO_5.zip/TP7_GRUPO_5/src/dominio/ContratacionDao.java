package dominio;

public class ContratacionDao {

}
